#!/bin/sh
#DUMP=/usr/bin/mysqldump
#OUT_DIR=/var/www/mysql_bak
#LINUX_USER=root
#DB_NAME=cizc
#DB_USER=root
#DB_PASS=pwd123456
#DAYS=7
#cd $OUT_DIR
#DATE='date+%Y_%m_%d'
#OUT_SQL="$DATE.sql"
#TAR_SQL="cizc_bak_$DATE.tar.gz"
#$DUMP -U$DB_USER -P$DB_PASS $DB_NAME --default-character-set=utf8 --opt -Q -R --skip-lock-tables>$OUT_SQL
#tar -czf $TAR_SQL ./$OUT_SQL
#rm $OUT_SQL
#chown $LINUX_USER:$LINUX_USER $OUT_DIR/$TAR_SQL
#find $OUT_DIR -name "cizi_bak*" -type f -mtime +$DAYS -exec rm{} \;

filename='date +%Y%m%d'
mysqldump -uroot -ppwd123456 cizc>/var/www/mysql_bak/cizc_${filename}.sql
