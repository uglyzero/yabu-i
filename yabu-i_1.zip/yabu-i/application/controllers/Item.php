<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Item extends CI_Controller {

	public function index()
	{
		//$this->output->cache(60);
		$this->load->model('article_model','art');
		$data['article'] = $this->art->article_cid(2,20);
		//p($data);


		$this->load->view('index/itemlistpic.html',$data);
		//echo "hello world";
	}
	public function view()
	{
		$aid = $this->uri->segment(3);
		$this->load->model('article_model','art');
		$this->load->model('item_model','item');
		$data['art'] = $this->art->article_cid_view(2,$aid);
		$data['item'] = $this->item->item_art_one($aid);
		if($data['item']){
			$data['item_pro']= $this->item->item_pro_check($data['item'][0]['Id']);
		}
		
		//p($data);
		if($data['art'] && $data['item'] ){
			$this->load->view('index/itemview.html',$data);
		}
		else{
			redirect(base_url().'index.php/item');
		}
		//echo "hello world";
	}
}
