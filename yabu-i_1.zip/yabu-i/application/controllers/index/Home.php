<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
		$data['title']='title';
		$data['name']= array('fenli','nashi','deke');

		//$this->load->helper('url');
		echo site_url();
		echo '<br />';
		//echo base_url();
		
		p($data);/*zidingyihanshu*/
		//$this->load->view('index/home',$data);
		//echo "hello world";
	}
	public function listnews()
	{
		//$this->load->view('welcome_message');
		echo "hello world i'm list";
	}
}
