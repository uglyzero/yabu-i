<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Article extends CI_Controller {
	/*
	 *构造函数
	*/
	public function __construct(){
		parent::__construct();
		$this->load->model('article_model','art');
	}
	public function index()
	{
		//$this->output->enable_profiler(TRUE);
		/*分页*/
		$this->load->library('pagination');
		$perPage = 10;
		$config['base_url'] = 'http://yabu-i.com/index.php/admina/article/index';
		$config['total_rows'] = $this->db->count_all_results('article');
		$config['per_page'] = $perPage;
		$config['uri_segment'] =4;
		$config['first_link'] = 'Home';
		$config['prev_link'] = '&#8249;';
		$config['next_link'] = '&#8250;';
		$config['last_link'] = 'End';
		$config['full_tag_open'] = '<ul class="pagination">';  
        $config['full_tag_close'] = '</ul>';  
        $config['first_tag_open'] = '<li>';  
        $config['first_tag_close'] = '</li>';  
        $config['prev_tag_open'] = '<li>';  
        $config['prev_tag_close'] = '</li>';  
        $config['next_tag_open'] = '<li>';  
        $config['next_tag_close'] = '</li>';  
        $config['cur_tag_open'] = '<li class="active"><a>';  
        $config['cur_tag_close'] = '</a></li>';  
        $config['last_tag_open'] = '<li>';  
        $config['last_tag_close'] = '</li>';  
        $config['num_tag_open'] = '<li>';  
        $config['num_tag_close'] = '</li>'; 
		$this->pagination->initialize($config);
		$data['links'] = $this->pagination->create_links();
		//p($data);die;
		$offset = $this->uri->segment(4);/*网趾片段*/
		$this->db->limit($perPage,$offset);

		//$this->load->model('article_model','art');//构造函数中已引用
		$data['article'] = $this->art->article_list();
		//print_r($data);die;
		$this->load->view('admin_DetailOa/articlelist.html',$data);
		//echo "hello world";
	}

	/*文章发布*/
	public function article_add()
	{
		//载入form辅助函数
		$this->load->helper('form');
		$this->load->view('admin_DetailOa/articleadd.html');
	}
	/*文章发布提交*/
	public function article_add_act()
	{
		//表单验证类
		$this->load->library('form_validation');
		$keyword=$this->input->post('keyword');
		$keywordv='';
		foreach ($keyword as $value) {
			$keywordv  .= '|'. $value;
		}
		//图片上传
		
		if(!empty($_FILES['img']['tmp_name'])){
			$config['upload_path']      = './uploads/';
	        $config['allowed_types']    = 'gif|jpg|png|jpeg';
	        $config['max_size']     = 10000;
	        $config['max_width']        = 1024;
	        $config['max_height']       = 768;
	        $config['file_name']	= time() . mt_rand(1000,9999);
	        $this->load->library('upload', $config);
	        $status = $this->upload->do_upload('img');
	        /*if($status){
	        	erro();
	        }*/
	        $wrong = $this->upload->display_errors();
	        if($wrong){
	        	erro($wrong);
	        }
	        $info = $this->upload->data();
	        p($info);//die();
	        //缩略图
	        $thumb['source_image'] = $info['full_path'];
	        $thumb['create_thumb'] = FALSE;
	        $thumb['maintain_ratio'] = TRUE;
	        $thumb['new_image'] = './uploads/thumb';
	        $thumb['width'] = 360;
	        $thumb['height'] = 270;
	        $this->load->library('image_lib',$thumb);
	        $status = $this->image_lib->resize();
	        
	        if($wrong){
	        	erro('缩略图失败');
	        }
	        $img = $info['file_name'];
	        //p($thumb);die;
    	}
		//验证规则
		//$this->form_validation->set_rules('title','文章标题','required|min_length[5]');
		//$this->form_validation->set_rules('cid','分类','integer');
		//$this->form_validation->set_rules('flag_headline','属性','integer');
		//$this->form_validation->set_rules('content','内容','required|min_length[20]');
		//$this->form_validation->set_rules('descript','摘要','required|max_length[20]');
		$status = $this->form_validation->run('article');
		//var_dump($form);
		if ($status){
			$data  = array('title' => $this->input->post('title'),
							'cid' => $this->input->post('cid'),
							'flag_headline' => $this->input->post('cid'),
							'content' => $this->input->post('content'),
							'descript' => $this->input->post('descript'),
							'keyword' => $keywordv,
							'cre_time' => time(),
							'img' => $img
			 );
			//$this->load->model('article_model','art');//构造函数中已引用
			$this->art->article_add($data);
			succes(base_url().'index.php/admina/article','添加成功！');
		}else{
			$this->load->helper('form');
			$this->load->view('admin_DetailOa/articleadd.html');
		}

	}
	/*文章修改*/
	public function article_edit()
	{
		//载入form辅助函数
		$this->load->helper('form');
		$aid = $this->uri->segment(4);
		////构造函数中已引用$this->load->model('article_model');
		$data['art'] = $this->art->article_edit($aid);
		$this->load->view('admin_DetailOa/articleedit.html',$data);
	}
	/*文章修改提交*/
	public function article_edit_act()
	{
		$this->load->library('form_validation');
		$keyword=$this->input->post('keyword');
		$keywordv='';
		foreach ($keyword as $value) {
			$keywordv  .= '|'. $value;
		}
		//p($keyword);p($keywords);die;
		//图片上传
		if(!empty($_FILES['img']['tmp_name'])){
			$config['upload_path']      = './uploads/';
	        $config['allowed_types']    = 'gif|jpg|png|jpeg';
	        $config['max_size']     = 10000;
	        $config['max_width']        = 1024;
	        $config['max_height']       = 768;
	        $config['file_name']	= time() . mt_rand(1000,9999);
	        $this->load->library('upload', $config);
	        $status = $this->upload->do_upload('img');
	        /*if($status){
	        	erro();
	        }*/
	        $wrong = $this->upload->display_errors();
	        if($wrong){
	        	erro($wrong);
	        }
	        $info = $this->upload->data();
	        //p($info);
	        //die();
	        //缩略图
	        $thumb['image_library'] = 'GD2';
	        $thumb['source_image'] = $info['full_path'];
	        $thumb['create_thumb'] = FALSE;
	        $thumb['maintain_ratio'] = TRUE;
	        $thumb['new_image'] = $info['file_path'].'thumb/';
	        $thumb['width'] = 360;
	        $thumb['height'] = 270;
	        $this->load->library('image_lib',$thumb);
	        $status = $this->image_lib->resize();
	        
	        if($wrong){
	        	erro('缩略图失败');
	        }
	        $img = $info['file_name'];
	        //p($thumb);die;
    	}
		//表单验证类
		$status = $this->form_validation->run('article');
		//var_dump($form);
			$aid = $this->input->post('aid');
		if ($status){
			$data  = array('title' => $this->input->post('title'),
							'cid' => $this->input->post('cid'),
							'flag_headline' => $this->input->post('cid'),
							'content' => $this->input->post('content'),
							'descript' => $this->input->post('descript'),
							'keyword' => $keywordv,
							'edt_time' => time()
			 );//p($data);die;
			if(!empty($img)){
				$data['img'] = $img;
			}
			//$this->load->model('article_model');//构造函数中已引用
			$this->art->article_edit_act($aid,$data);
			succes(base_url().'index.php/admina/article','修改成功！');
		}else{
			$this->load->helper('form');
			$data['art'] = $this->art->article_edit($aid);
			$this->load->view('admin_DetailOa/articleedit.html',$data);
		}

	}
	/*改状态flag=-1*/
	public function article_del()
	{
		//载入form辅助函数
		$this->load->helper('form');
		$aid = $this->uri->segment(4);
		$data['flag'] = -1;
		//$this->load->model('article_model');//构造函数中已引用
		$this->art->article_del($aid,$data);
			succes(base_url().'index.php/admina/article','修改成功！');
	}
}
