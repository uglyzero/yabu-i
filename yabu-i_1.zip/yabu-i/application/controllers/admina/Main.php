<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {

	public function index()
	{
		$data['title']='title';
		$data['name']= array('fenli','nashi','deke');

		$this->load->helper('url');
		//echo base_url();
		
		
		$this->load->view('admin_DetailOa/index.html',$data);
		//echo "hello world";
	}
	public function listnews()
	{
		//$this->load->view('welcome_message');
		echo "hello world i'm list";
	}
}
