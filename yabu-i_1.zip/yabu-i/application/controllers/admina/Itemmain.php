<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Itemmain extends CI_Controller {
	/*
	 *构造函数
	*/
	public function __construct(){
		parent::__construct();
		$this->load->model('item_model','item');
	}
	public function index()
	{
		//$this->output->enable_profiler(TRUE);
		/*分页*/
		$this->load->library('pagination');
		$perPage = 10;
		$config['base_url'] = '/admina/item/index';
		$config['total_rows'] = $this->db->count_all_results('item');
		$config['per_page'] = $perPage;
		$config['uri_segment'] =4;
		$config['first_link'] = 'Home';
		$config['prev_link'] = '&#8249;';
		$config['next_link'] = '&#8250;';
		$config['last_link'] = 'End';
		$config['full_tag_open'] = '<ul class="pagination">';  
        $config['full_tag_close'] = '</ul>';  
        $config['first_tag_open'] = '<li>';  
        $config['first_tag_close'] = '</li>';  
        $config['prev_tag_open'] = '<li>';  
        $config['prev_tag_close'] = '</li>';  
        $config['next_tag_open'] = '<li>';  
        $config['next_tag_close'] = '</li>';  
        $config['cur_tag_open'] = '<li class="active"><a>';  
        $config['cur_tag_close'] = '</a></li>';  
        $config['last_tag_open'] = '<li>';  
        $config['last_tag_close'] = '</li>';  
        $config['num_tag_open'] = '<li>';  
        $config['num_tag_close'] = '</li>'; 
		$this->pagination->initialize($config);
		$data['links'] = $this->pagination->create_links();
		//p($data);die;
		$offset = $this->uri->segment(4);/*网趾片段*/
		$this->db->limit($perPage,$offset);

		$data['item'] = $this->item->item_list();
		//print_r($data);die;
		$this->load->view('admin_DetailOa/itemlist.html',$data);
		//echo "hello world";
	}

	/*项目发布stepone*/
	public function item_add_stepone()
	{
		
		//载入form辅助函数
		//echo "stepone";
		//$this->load->helper('form');
		$aid = $this->uri->segment(4);
		//判断item表是否有此aid关联项目状态flag<4的记录
		$data = $this->db->select('Id,flag')->where(array('art_id' =>$aid))->order_by('Id','desc')->limit(1)->get('item')->result_array();
		//foreach ($data as $key => $value) {
			//echo $value['flag'];
		//}
		if($data){
			if($data[0]['flag']<4 )
			{
				redirect('/index.php/admina/Itemmain/item_edit_steptwo/'.$data[0]['Id']);

			}
		}
		else
		{
			//echo "no";
			$sql = "insert into item (art_id,title) select Id,title from article where Id=" .$aid. " and cid=2";
			$query = $this->db->query($sql);
			$itemid = $this->db->insert_id();
			if($itemid>0){
				redirect('/index.php/admina/Itemmain/item_edit_steptwo/'.$itemid);
			}
			else{
				erro('参数错误');
			}

		}
		//$this->load->view('admin_DetailOa/articleadd.html');
	}
	/*
	**项目信息编辑
	*/
	public function item_edit_stepone()
	{
		//载入form辅助函数
		$this->load->helper('form');
		$id = $this->uri->segment(4);
		$data['item']= $this->item->item_findone($id);
		//p($data);
		//$this->load->view('admin_DetailOa/itemedit.html',$data);
		if($data['item']){
			//查询item_pro表关联$itemid记录
				$data['item_pro']= $this->item->item_pro_check($id);
				$this->load->view('admin_DetailOa/itemedit_invest.html',$data);
			}
			else{
				erro('项目id错误');
			}
	}
	
	/*项目信息修改提交*/
	/*文章修改提交*/
	public function item_edit_stepone_act()
	{
		$this->load->library('form_validation');
		//表单验证类
		$status = $this->form_validation->run('item');
		//var_dump($form);
			$id = $this->input->post('aid');
		if ($status){
			$beg_time=strtotime($this->input->post('beg_time'));
			$end_time=strtotime($this->input->post('end_time'));
			$data  = array('title' => $this->input->post('title'),
							'beg_time' => $beg_time,
							'end_time' => $end_time,
							'goal_line' => $this->input->post('goal_line'),
							'c_userid' => 'zero',
							'flag' => 1,
							'c_time' => time()
			 );//p($data);//die;
			//echo "ok";
			$return = $this->item->item_edit_stepone_act($id,$data);
			if ($return>0)
			{
				succes(base_url().'index.php/admina/itemmain/item_edit_steptwo/'.$id,'修改成功！');
			}
			else{
				erro('数据更新失败返回');
			}
			
		}else{
			$this->load->helper('form');
			$data['item']= $this->item->item_findone($id);
			if($data['item']){
			//查询item_pro表关联$itemid记录
				$data['item_pro']= $this->item->item_pro_check($id);
				$this->load->view('admin_DetailOa/itemedit_invest.html',$data);
			}
			else{
				erro('项目id错误');
			}
		}

	}
	/*
	**项目编辑第二步投资回报
	*/
	public function item_edit_steptwo()
	{
		//echo "step two";//die;
		//载入form辅助函数
		$this->load->helper('form');
		$id = $this->uri->segment(4);
		//判断item表是否$id记录
		$data['item']= $this->item->item_findone($id);
		if($data['item']){
			//查询item_pro表关联$itemid记录
			$data['item_pro']= $this->item->item_pro_check($id);
//p($item_pro);
			$this->load->view('admin_DetailOa/itemedit_invest.html',$data);
		}
		else{
			erro('项目id错误');
		}
		
	}
	/*项目编辑第二步投资回报增加*/
	public function item_edit_steptwo_add_act()
	{
		$this->load->library('form_validation');
		//表单验证类
		$status = $this->form_validation->run('item_pro');
		//var_dump($form);
		$id = $this->input->post('item_id');
		if ($status){
			$data  = array('standard' => $this->input->post('standard'),
							'invest_price' => $this->input->post('invest_price'),
							'repay' => $this->input->post('repay'),
							'pro_price' => $this->input->post('pro_price'),
							'art_id' => $this->input->post('art_id'),
							'item_id' => $this->input->post('item_id')
			 );//p($data);die;
			$return = $this->item->item_edit_steptwo_add_act($data);
			if ($return>0)
			{
				succes(base_url().'index.php/admina/itemmain/item_edit_steptwo/'.$id,'操作成功！');
			}
			else{
				erro('数据跟新失败返回');
			}
			
		}else{
			$this->load->helper('form');
			$data['item']= $this->item->item_findone($id);
			if($data['item']){
			//查询item_pro表关联$itemid记录
				$data['item_pro']= $this->item->item_pro_check($id);
//p($data['item_pro']);
				$this->load->view('admin_DetailOa/itemedit_invest.html',$data);
			}
			else{
				erro('项目id错误');
			}
		}

	}
	/*项目编辑第二步投资回报修改*/
	public function item_edit_steptwo_edit_act()
	{
		$this->load->library('form_validation');
		//表单验证类
		$status = $this->form_validation->run('item_pro');
		//var_dump($form);
		$id = $this->input->post('item_id');
		$pid = $this->input->post('pid');
		if ($status){
			$data  = array('standard' => $this->input->post('standard'),
							'invest_price' => $this->input->post('invest_price'),
							'repay' => $this->input->post('repay'),
							'pro_price' => $this->input->post('pro_price')
			 );//p($data);die;
			$return = $this->item->item_edit_steptwo_edit_act($data,$pid);
			if ($return>0)
			{
				succes(base_url().'index.php/admina/itemmain/item_edit_steptwo/'.$id,'操作成功！');
			}
			else{
				erro('数据跟新失败返回');
			}
			
		}else{
			$this->load->helper('form');
			$data['item']= $this->item->item_findone($id);
			if($data['item']){
			//查询item_pro表关联$itemid记录
				$data['item_pro']= $this->item->item_pro_check($id);
//p($data['item_pro']);
				$this->load->view('admin_DetailOa/itemedit_invest.html',$data);
			}
			else{
				erro('项目id错误');
			}
		}

	}
	/*项目提交审核*/
	public function item_check_submit()
	{
		$itemid = $this->input->post('item_id');
		$act = $this->input->post('act');
		if($act=='submit'){
			$data  = array('flag' => 4);
			$where = array('Id' => $itemid,'flag< ' =>4 );
		}
		elseif($act=='check'){
			$data  = array('flag' => 5);
			$where = array('Id' => $itemid,'flag= ' =>4 );
		}
		elseif($act=='start'){
			$data  = array('flag' => 6);
			$where = array('Id' => $itemid,'flag= ' =>5 );
		}
		elseif($act=='end'){
			$data  = array('flag' => 9);
			$where = array('Id' => $itemid,'flag= ' =>6 );
		}
		$subminttype =array("submit","check","start","end");
		//如果提交类型为数组中动作则执行更新
		if(in_array($act, $subminttype)){
			$return = $this->item->item_check($data,$where);
			if ($return>0)
			{
				//succes(base_url().'index.php/admina/itemmain/item_edit_steptwo/'.$itemid,'操作成功！');
				succes(base_url().'index.php/admina/itemmain/','操作成功！');
			}
			else{
				erro('数据跟新失败返回');
			}
		}
		else{
			erro('提交操作被拒绝');
		}

	}
}
