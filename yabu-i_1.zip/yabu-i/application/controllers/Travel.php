<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Travel extends CI_Controller {

	public function index()
	{
		
		$this->load->model('article_model','art');
		$data['article'] = $this->art->article_blog(10);
		//p($data);


		$this->load->view('index/travel.html',$data);
		//echo "hello world";
	}
	public function view()
	{
		$aid = $this->uri->segment(3);
		$this->load->model('article_model','art');
		$data['art'] = $this->art->article_cid_view(4,$aid);
		//p($data);
		if($data['art']){
			$this->load->view('index/travelview.html',$data);
		}
		else{
			redirect(base_url().'index.php/travel');
		}
		//echo "hello world";
	}
}
