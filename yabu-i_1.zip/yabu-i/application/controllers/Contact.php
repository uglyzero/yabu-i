<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contact extends CI_Controller {
	public function index()
	{
		//$this->output->enable_profiler(TRUE);
		/*分页*/
		$this->load->library('pagination');
		$perPage = 10;
		$config['base_url'] = base_url().'index.php/admina/contact/index';
		$config['total_rows'] = $this->db->count_all_results('contact');
		$config['per_page'] = $perPage;
		$config['uri_segment'] =4;
		$config['first_link'] = 'Home';
		$config['prev_link'] = '&#8249;';
		$config['next_link'] = '&#8250;';
		$config['last_link'] = 'End';
		$config['full_tag_open'] = '<ul class="pagination">';  
        $config['full_tag_close'] = '</ul>';  
        $config['first_tag_open'] = '<li>';  
        $config['first_tag_close'] = '</li>';  
        $config['prev_tag_open'] = '<li>';  
        $config['prev_tag_close'] = '</li>';  
        $config['next_tag_open'] = '<li>';  
        $config['next_tag_close'] = '</li>';  
        $config['cur_tag_open'] = '<li class="active"><a>';  
        $config['cur_tag_close'] = '</a></li>';  
        $config['last_tag_open'] = '<li>';  
        $config['last_tag_close'] = '</li>';  
        $config['num_tag_open'] = '<li>';  
        $config['num_tag_close'] = '</li>'; 
		$this->pagination->initialize($config);
		$data['links'] = $this->pagination->create_links();
		//p($data);die;
		$offset = $this->uri->segment(4);/*网趾片段*/
		$this->db->limit($perPage,$offset);

		$this->load->model('contact_model');//构造函数中已引用
		$data['contact'] = $this->contact_model->clist();
		//print_r($data);die;
		$this->load->view('admin_DetailOa/contactlist.html',$data);
		
	}

		public function addmessage()
			{
				//表单验证类
				$this->load->library('form_validation');
				//验证规则
				$status = $this->form_validation->run('contact');// /config/form_validation.php配置
				$ip=$this->input->ip_address();
				//echo date("Y-m-d H:i:s",time()-3600); echo date("Y-m-d H:i:s",time());die;
				if ($status){
					$data  = array('title' => $this->input->post('title'),
									'company' => $this->input->post('company'),
									'tel' => $this->input->post('tel'),
									'message' => $this->input->post('message'),
									'name' => $this->input->post('name'),
									'cretime' => time(),
									'IP' => $ip
					 );
					$this->load->model('contact_model');
					$this->contact_model->add($data);
					succes(base_url(),'提交成功！');
				}else{
					erro('请仔细检查提交信息格式是否正确!');
				}
			}

}