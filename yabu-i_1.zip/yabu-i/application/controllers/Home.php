<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
		$this->output->cache(60);
		//表单验证类
		$this->load->library('form_validation');
		$this->load->model('article_model','art');
		$data['article'] = $this->art->article_cid(2,12);
		//p($data);


		$this->load->view('index/index.php',$data);
		//echo "hello world";
	}
}
