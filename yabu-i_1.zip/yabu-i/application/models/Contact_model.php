<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contact_model extends CI_Model {

	/*查看文章*/
	public function clist()
	{
		//$data = $this->db->select('article.id_article,title,name,created')->from('article_lang')->join('article','article.id_article=article_lang.id_article')->order_by('article.id_article','desc')->get()->result_array();
		$data = $this->db->select('Id,title,company,name,tel,message,IP,cretime')->from('contact')->order_by('Id','desc')->get()->result_array();
		return $data;
	}
	/*添加article*/
	public function add($data)
	{
		$sql = "SELECT Id FROM contact WHERE IP = ? AND cretime > ? limit 1";
		//$statu = $this->db->query($sql, array($data['IP'], $data['cretime']-3600));
		$statu = $this->db->select('count(Id) num')->from('contact')->where(array('IP' => $data['IP'],'cretime >' => $data['cretime']-3600))->limit(1)->get()->result_array();
		//p($statu);die;
		if($statu[0]['num'] > 3){erro('您的提交信息过于频繁，请稍后再试！');}
		else{
			$this->db->insert('contact',$data);
		}
		
	}
	


}
