<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Item_model extends CI_Model {

	/*查看文章*/
	public function item_list()
	{
		//$data = $this->db->select('article.id_article,title,name,created')->from('article_lang')->join('article','article.id_article=article_lang.id_article')->order_by('article.id_article','desc')->get()->result_array();
		$data = $this->db->from('item')->order_by('Id','desc')->get()->result_array();
		return $data;
	}
	/*添加item*/
	public function item_add($data)
	{
		$this->db->insert('item',$data);
	}
	/*查询itemId*/
	public function item_findone($id)
	{
		$data = $this->db->where(array('Id' =>$id))->get('item')->result_array();
		return $data;
	}
	/*查询item_pro*/
	public function item_pro_check($id)
	{
		$data = $this->db->where(array('item_id' =>$id))->get('item_pro')->result_array();
		return $data;
	}
	/*项目修改且flag<4提交审核前*/
	public function item_edit_stepone_act($id,$data)
	{
		$this->db->update('item',$data,array('Id' =>$id,'flag<' =>'4'));
		$ret = $this->db->affected_rows();
		return $ret;
	}
	/*添加项目投资回报*/
	public function item_edit_steptwo_add_act($data)
	{
		$this->db->insert('item_pro',$data);
		$ret = $this->db->affected_rows();
		return $ret;
	}
	/*修改项目投资回报*/
	public function item_edit_steptwo_edit_act($data,$pid)
	{
		$this->db->update('item_pro',$data,array('Id' =>$pid));
		$ret = $this->db->affected_rows();
		return $ret;
	}
	/*改状态flag*/
	public function item_check($data,$where)
	{
		$data = $this->db->update('item',$data,$where);
		//echo $this->db->last_query();die;
		$ret = $this->db->affected_rows();
		return $ret;
	}
	/*前台项目页面使用articleid查询item最新一条 状态已开始flag>=6*/
	public function item_art_one($id)
	{
		$data = $this->db->where(array('art_id' =>$id,'flag >' =>5))->get('item')->result_array();
		return $data;
	}
}
