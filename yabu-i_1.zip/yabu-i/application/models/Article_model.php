<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Article_model extends CI_Model {

	/*查看文章*/
	public function article_list()
	{
		//$data = $this->db->select('article.id_article,title,name,created')->from('article_lang')->join('article','article.id_article=article_lang.id_article')->order_by('article.id_article','desc')->get()->result_array();
		$data = $this->db->select('Id,title,descript,cre_time,cid')->from('article')->where('flag=1')->order_by('Id','desc')->get()->result_array();
		return $data;
	}
	/*添加article*/
	public function article_add($data)
	{
		$this->db->insert('article',$data);
	}
	/*编辑*/
	public function article_edit($aid)
	{
		$data = $this->db->where(array('Id' =>$aid))->get('article')->result_array();
		return $data;
	}
	/*编辑修改*/
	public function article_edit_act($aid,$data)
	{
		$this->db->update('article',$data,array('Id' =>$aid));
		
	}
	/*改状态flag=-1*/
	public function article_del($aid,$data)
	{
		$data = $this->db->update('article',$data,array('Id' =>$aid));

	}
	/*分类列表
	*$cid分类新闻 项目 
	*$num读取条数
	*/
	public function article_cid($cid,$num)
	{
		$data = $this->db->select('Id,title,img,keyword,descript')->from('article')->where(array('cid' =>$cid,'flag_headline' => '2','flag' => '1'))->order_by('Id','desc')->limit($num)->get()->result_array();
		//echo $this->db->last_query();
		return $data;

	}
	/*按分类显示article
	*$cid分类新闻 项目 
	*$Id articleid
	*/
	public function article_cid_view($cid,$aid)
	{
		$data = $this->db->where(array('Id' =>$aid,'cid'=>$cid,'flag' => '1'))->get('article')->result_array();
		//echo $this->db->last_query();die;
		return $data;

	}
	/*分类列表blog
	*$num读取条数
	*/
	public function article_blog($num)
	{
		$data = $this->db->select('Id,title,img,keyword,descript,content')->from('article')->where(array('cid' =>'4','flag' => '1'))->order_by('Id','desc')->limit($num)->get()->result_array();
		//echo $this->db->last_query();
		return $data;

	}
}
