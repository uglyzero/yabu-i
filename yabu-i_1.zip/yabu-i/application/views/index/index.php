﻿<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<title>鸦哺之爱 为家乡代言 农业众筹</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="东北大米、通河大米、稻花香、乌鸦泡、兴隆林业局、东北特产、山野菜、众筹、农业、农业众筹、农副产品、农业众筹、林业养殖">
	<meta name="keywords" content="东北大米,通河大米,稻花香、乌鸦泡,兴隆林业局,东北特产,山野菜,众筹,农业,农业众筹,农副产品,农业众筹,林业养殖">
	<meta name="author" content="零度">
		<!-- STYLESHEETS --><!--[if lt IE 9]><script src="../js/flot/excanvas.min.js"></script><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script><![endif]-->
	<link rel="stylesheet" type="text/css" href="/style/base/css/cloud-admin-frontend.css" >
	<link href="/style/base/font-awesome/css/font-awesome.min.css" rel="stylesheet">
	<!-- ANIMATE -->
    <link href="/style/base/css/amimatecss/animate.min.css" rel="stylesheet">
	<!-- COLORBOX -->
	<link rel="stylesheet" type="text/css" href="/style/base/js/colorbox/colorbox.min.css" />
	<!-- CAROUSEL -->
    <link href="/style/base/css/carousel.css" rel="stylesheet">
	<!-- FONTS 
	<link href='http://fonts.useso.com/css?family=Open+Sans:300,400,600' rel='stylesheet' type='text/css'>-->
</head>
<body>
	<!-- PAGE -->
	<div id="page">
		<!-- NAV-BAR -->
		<div id="nav-bar">
			<div class="container">
				<div class="row">
					<div class="col-sm-3 col-md-3  col-xs-4">
						<div class="logo" >
							<a href="/"><img src="/style/base/img/logo/logo.png" height="40" alt="logo name"/></a>
						</div>
					</div>
					<div class="col-md-2 col-sm-2  col-xs-2 fa-sort" style="margin-top: 15px;">选择地域</div>
					<div class="col-sm-7  col-md-7 col-xs-6">
						<nav id="fixed-top-navigation">
							<ul class="list-inline pull-right">
								<li><a href="#portfolio">乡产</a></li>
								<li><a href="#features">乡味</a></li>
								<li><a href="#sound">乡音</a></li>
								<li><a href="#about">乡景</a></li>
								<li><a href="#contact">联系我们</a></li>
								
							</ul>
						</nav>
					</div>
				</div>
			</div>
		</div>
		<!--/NAV-BAR -->
		<!-- HEADER -->
		<section id="header" data-type="background" data-speed="10">
			<!-- OVERLAY -->
			<!-- <div class="overlay"> -->
				<div id="sidebar-collapse" class="sidebar-collapse btn visible-xs">
					<i class="fa fa-bars" data-icon2="fa fa-bars" data-icon1="fa fa-bars"></i>
				</div>
				<div class="divide60"></div>
				<div id="mobile-menu" class="list-group collapse text-center">
				  <a href="#portfolio" class="list-group-item">乡产</a>
				  <a href="#features" class="list-group-item">乡味</a>
				  <a href="#sound" class="list-group-item">乡音</a>
				  <a href="#about" class="list-group-item">乡景</a>
				  <a href="#contact" class="list-group-item">联系我们</a>
				</div>

					<!-- HERO -->
					<div class="container-transparent text-center">
						<!--<ul class="heronav left hidden-xs">
							<li><a href="#features">乡产</a></li>
							<li><a href="#portfolio">乡味</a></li>
							<li><a href="#sound">乡音</a></li>
						</ul>
						<ul class="heronav right hidden-xs">
							<li><a href="#about">乡景</a></li>
							<li><a href="#contact">联系我们</a></li>
						</ul>-->
						<h1>
							<img src="/style/base/img/logo/logo.png" height="50" alt="logo name">
						</h1>
						<h1 class="page-title"> 羔羊跪乳 乌鸦反哺 为家乡建设贡献力量</h1>
						<h4 class="page-sub-title">总有一种魂牵梦萦的味道在记忆里生长，总有一种无法描摹的乡味让人忘怀不了
						<br>
							骨子里恒有的家乡味道，让凡俗的日子泛起涟漪，唤起对故乡依恋缱绻的情愫。<br>
							在异乡奋斗的我们，或在街角、在家中品尝到来自家乡的美味，开心也好失意也罢，它会化作我们继续前行的动力<br>请记住这是来自家乡的问候和亲人的关怀……
						</h4>
						<div class="showcase">
							<a class="btn btn-warning btn-lg hidden-xs" href="#portfolio">鸦哺之爱 &nbsp;&nbsp;<i class="fa fa-play"></i></a>
							<a class="btn btn-warning btn-sm visible-xs" href="#portfolio">鸦哺之爱 &nbsp;&nbsp;<i class="fa fa-play"></i></a>
						</div>
					</div>
				<!--/HERO -->
			<!-- </div> -->
			<!--/OVERLAY -->
		</section>
		<!--/HEADER -->

		<!-- FEATURES UNIT -->
		<section id="portfolio" class="color-light">
			<div class="container">
				<div class="divide40"></div>
				<div class="row">
					<div class="col-md-12">
							<h2 class="text-center">
							<span class="bigintro" style="color:#9ece33">山水相依 物产丰富</span>
							</h2>
					</div>
				</div>
				<div class="divide60"></div>
				<div class="row">
					<div class="col-md-3 col-sm-6">
						<div class="feature">
							<i class="extralarge fa fa-slack"></i>
							<br/><br/>
							<h3>农</h3>
							<br/>
							<p>松花江与我擦身而过，这里水草丰富、泡泽密布、土地肥沃、良田千顷，这里的稻米获国家A级绿色食品认证，并获批国家地理标志保护产品。盛夏时节白天喜看稻菽千重浪，兼闻十里稻花香，夜晚更有蛙叫虫鸣的大自然小夜曲相伴而眠，绝佳的生态环境，优质的稻谷杂粮与你分享。</p>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="feature">
							<i class="extralarge fa fa-tree"></i>
							<br/><br/>
							<h3>林</h3>
							<br/>
							<p>位于小兴安岭南麓森林资源丰富，刺五加、蓝莓、山葡萄、五味子、蘑菇、木耳、猕猴头、蕨菜、刺嫩芽、山丁子、松子、榛子、山核桃等，绿色药用保健是野生物产的特色标签。</p>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="feature">
							<i class="extralarge fa fa-github"></i>
							<br/><br/>
							<h3>畜</h3>
							<br/>
							<p>棒打狍子瓢舀鱼野鸡飞到饭锅里，虽然此景难复但江湖也有传说，天上龙肉地下驴肉，吃过火烧的再来这里看看飞龙吧。特别提示：来东北不想当那个或许是因为好奇心重亦或是很傻很天真而被棒杀的狍子，请不要总盯着一个人看，客气的会问“你瞅啥”，当然你也可以入乡随俗的回一句“瞅你咋地”，结果我不知道…… </p>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="feature">
							<i class="extralarge fa fa-anchor"></i>
							<br/><br/>
							<h3>渔</h3>
							<br/>
							<p>你吃得出野生鱼和饲养鱼的区别吗，同样是鲤鱼差距咋那么大呢。你还知道冷水鱼与普通淡水鱼的不同吗，快来这里寻找答案吧。 </p>
						</div>
					</div>
				</div>
				<div class="divide30"></div>
			</div>
		</section>
		<!--/FEATURES UNIT  -->
		<!-- PORTFOLIO UNIT -->
		<section id="features" class="color-light text-center">			
				<div class="divide40"></div>
					<div class="row">
						<div class="col-md-12">
								<h2 class="text-center">
								<span class="bigintro" style="color: #9ece33">绿色 生态 健康</span>
								</h2>
						</div>
					</div>
					<div class="divide60"></div>
					<div class="row">
						<div class="col-md-6 col-md-offset-3">
							<div id="filters" class="text-center btn-group">
								  <div  class="hidden-xs">
									  <a class="btn btn-lg btn-primary active" data-filter="*" href="#">All</a>
									  <a class="btn btn-lg btn-warning" data-filter=".farming" href="#">农业</a>
									  <a class="btn btn-lg btn-success" data-filter=".forestry" href="#">林业</a>
									  <a class="btn btn-lg btn-danger" data-filter=".livestock" href="#">畜渔</a>
								  </div>
								  <div class="visible-xs">
									   <select id="e1" class="form-control">
											<option value="*">All</option>
											<option value=".farming">农业</option>
											<option value=".forestry">林业</option>
											<option value=".livestock">畜渔</option>
										</select>
								  </div>
							</div>
						</div>
					</div>
					<div class="divide40"></div>
					<div class="container">
						<div id="filter-items" class="row isotope" >
							
							<?php foreach($article as $v):?>
							<div class="col xs-12 col-sm-4 <?php echo strtr($v['keyword'],'|',' ')?> item">
								<div class="filter-content">
									<a href="<?php echo base_url().'index.php/item/view/' . $v['Id']?>">
									<img src="<?php echo "/uploads/".$v['img'];?>" alt="<?php echo $v['title']?>" class="img-responsive" /></a>
									<div class="image-content">
										<!--<h4>Image Title</h4>-->
										<p class="hidden-xs hidden-sm">
											<?php echo $v['descript']?>
										</p>
										<a href="/style/base/img/pay50.jpg" class="btn btn-sm btn-warning colorbox-button">众筹结束-点我订购</a>
									</div>
								</div>
							</div>
							<?php endforeach?>
						</div>
					</div>
					<div class="divide40"></div>
		</section>
		
			

		<!-- TESTIMONIALS -->
		<section id="sound" data-type="background" data-speed="10" class="pages textcenter">
			<div class="parallax-overlay">
			<div class="divide40"></div>
				<h2 class="text-center">
					<span class="bigintro-light">土著老炮</span>
				</h2>
				 <div id="myCarousel" class="carousel slide">
				  <!-- Indicators -->
				  <ol class="carousel-indicators">
					<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
					<li data-target="#myCarousel" data-slide-to="1"></li>
					<li data-target="#myCarousel" data-slide-to="2"></li>
					<li data-target="#myCarousel" data-slide-to="3"></li>
				  </ol>
				  <div class="carousel-inner">
					<div class="item active">
					  <div class="container">
						<div class="carousel-caption">
						  <div class="row">
							<div class="circular col-md-6">
								<img src="/style/base/img/testimonials/1.jpg" alt="headshot #1" />
								<h3>有机水稻生产基地</h3>
								<p>"通河县乌鸦泡素有“稻谷之乡”和“水稻王国”的美誉，本地出产稻米获国家A级绿色食品认证，并获批国家地理标志保护产品。米质颗粒整齐均匀，晶莹剔透，柔韧绵软，气味芳香甘醇，蒸煮粘香适口，米饭过夜不回生"</p>
								<!--<h4>www.firstname.com</h4>-->
							</div>
							<div class="circular col-md-6">
								<img src="/style/base/img/testimonials/2.jpg" alt="种地老炮 #2" />
								<h3>种地老炮</h3>
								<p>"我是乔老汉年过半百，祖辈一直在此种地为生，吃过我家米的都说好，香、有嚼头，用你们城里流行话说就是香糯Q弹。其实除了我们这儿得天独厚的地理条件，选种也是很重要滴，种地也是门学问，你要想学或体验生活来这找我"</p>
								
							</div>
						 </div>
						</div>
					  </div>
					</div>
					<div class="item">
					  <div class="container">
						<div class="carousel-caption">
						  <div class="row">
							<div class="circular col-md-6">
								<img src="/style/base/img/testimonials/3.jpg" alt="木耳君 #3" />
								<h3>木耳君</h3>
								<p>"我是大学生回乡创业者，依靠家乡自然资源的优势种植木耳椴，是长在树林椴木上的非菌袋种植的那种哦，采天地之灵气，集日月之精华，口味纯正，绿色健康。"</p>
								
							</div>
							<div class="circular col-md-6">
								<img src="/style/base/img/testimonials/7.jpg" alt="蘑菇妹 #7" />
								<h3>蘑菇妹</h3>
								<p>"小妹家在小兴安岭青峰林场，自然环境就不必多说了，一片大森林，在城里呆久了的你是不是有些羡慕呢，夏秋是上山采蘑菇的最佳时节，欢迎您来我家乡做客，回归自然品山珍野味"</p>
								
							</div>
						 </div>
						</div>
					  </div>
					</div>
					<div class="item">
					  <div class="container">
						<div class="carousel-caption">
						  <div class="row">
							<div class="circular col-md-6">
								<img src="/style/base/img/testimonials/5.jpg" alt="山林二师兄 #4" />
								<h3>山林二师兄</h3>
								<p>"自从身份暴露后我离开了庄里盘踞于山林之中，这里空气清新吃的香睡得好，只是时常会想念你高小姐，记得你说不喜欢我胖胖的肥暄暄，我每天都有锻炼，肌肉健硕了很多，我想这样你也许会喜欢我多一点，"</p>
								
							</div>
							<div class="circular col-md-6">
								
								<img src="/style/base/img/testimonials/4.jpg" alt="绿野仙踪 #5" />
								<h3>绿野仙踪</h3>
								<p>"靠山吃山，我是跑山者，每年夏秋时节是我最忙的时期，刺嫩芽、老蕨菜、榛蘑、猴头菇、五味子、刺五加、核桃、松子、野山参……翻山越岭上天入地只为你寻找山林深处那份原始的味道，拥抱森林感恩自然，我是大自然的搬运工^_^"</p>
							</div>
						 </div>
						</div>
					  </div>
					</div>
					<div class="item">
					  <div class="container">
						<div class="carousel-caption">
						  <div class="row">
							<div class="circular col-md-6">
								<img src="/style/base/img/testimonials/6.jpg" alt="鸡婆婆 #6" />
								<h3>鸡婆婆</h3>
								<p>"快乐啄小虫，幸福咯咯哒~我有一个美丽的愿望张开翅膀就能碰到天，快把跑道让开我要起飞啦……扑啦啦~扑啦啦~额~好吧我承认我不会飞"</p>
								
							</div>
							<div class="circular col-md-6">
								<img src="/style/base/img/testimonials/8.jpg" alt="蜂花雪蜜 #8" />
								<h3>蜂花雪蜜</h3>
								<p>"幸福｜很简单—有人爱、有事业、有所期待、有蜂花雪蜜，我做的是甜蜜事业"</p>
								
							</div>
						 </div>
						</div>
					  </div>
					</div>
				  </div>
				  <a class="left carousel-control" href="#myCarousel" data-slide="prev"><span class="fa fa-chevron-left fa-2x"></span></a>
				  <a class="right carousel-control" href="#myCarousel" data-slide="next"><span class="fa fa-chevron-right fa-2x"></span></a>
				</div>
				<div class="divide40"></div>
			
			</div>
		</section>
		<!--/TESTIMONIALS -->
				
		<!-- ABOUT UNIT -->
		<section id="about" class="color-light text-center" data-type="background" data-speed="10" >
			<div style="background: url(/style/base/img/map.jpg) 0 0 no-repeat fixed;width: 100%;background-size:100%;">
			<div class="container">
				<div class="divide40"></div>
				<div class="row">
					<div class="col-md-12">
							<h2 class="text-center">
							<span class="bigintro">秘史传说</span>
							</h2>
					</div>
				</div>
				<div class="divide20"></div>
				<div class="row">
					<div class="col-md-12 " style="text-align: left;">
						<p><h4 style="color: #555555;size: 34px; font-weight: 800">为什么紫禁城里要喂养乌鸦? 相传努尔哈赤青年时期随军打仗不幸战败，被敌军追杀，负伤坠马于草泽之中昏死过去，周围的乌鸦成群成片附于其身，而彼时追兵也从此经过却不曾发现，受伤的努尔哈赤遂躲过此劫且最后建功立业。因此紫禁城内立梭罗杆并设专人喂食乌鸦。</h4></p><p ><h4 style="color: #555555;size: 18px;">So 你知道努尔哈赤被救的地方吗——It's 乌鸦泡 </h4></p>
					</div>
				</div>
			</div>
			<div class="divide60"></div>
			</div>
		</section>
		<!-- /ABOUT UNIT -->
		<!-- TEAM UNIT -->
		<section id="team" class="color-light text-center">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
							<h2 class="text-center">
							<span class="bigintro">家乡美景</span>
							</h2>
					</div>
				</div>
				<div class="divide40"></div>
				<div class="row">
					<div class="col-md-3 col-sm-6">
						<div class="team">
							<a href="/travel"><img alt="" src="/style/base/img/1.jpg"></a>
							<h3>森林小火车</h3>
							<p>世界最长的森林窄轨铁路，当时由通河县乌鸦泡镇向西至兴隆镇，横跨巴彦、木兰、通河三县，随着林业改革不断深入，乌鸦泡开始的部分路段已被拆除，昔日林区运输的骄子已经退居二线，可它却给人留下原始的回味。</p>
							
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="team">
							<a href="/travel"><img alt="" src="/style/base/img/2.jpg"></a>
							<h3>香磨山慈航古寺</h3>
							<p>距木兰县城90公里处，是哈尔滨市周边地区最大的寺院也是闻名遐迩的旅游度假区，旅游区由香磨山、香磨山水库和慈航古寺三部分构成，在这里你可以领略山水风光参禅礼佛，或林间漫步，沐百鸟争鸣，或草地野欢，品美食之乐，在这莽莽林海，幽幽古迹中忘却烦恼、心旷神怡、流连忘返。</p>
							
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="team">
							<a href="/travel"><img alt="" src="/style/base/img/3.jpg"></a>
							<h3>鸡冠山</h3>
							<p>鸡冠山景区属省级地质公园和国家3A级景区，位于兴隆林业局沙河林场和浓河林场施业区内。鸡冠山景区奇峰罗列，风光峻秀，怪石嶙峋，春花吐艳，秋色斑斓。</p>
							<!--<a class="facebook" title="weibo" href="#"><i class="fa fa-weibo"></i></a>
							<a class="twitter" title="weixin" href="#"><i class="fa fa-weixin"></i></a>
							<a class="linkedin" title="qq" href="#"><i class="fa fa-qq"></i></a>-->
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="team">
							<a href="/travel"><img alt="" src="/style/base/img/4-1.jpg"></a>
							<h3>铧子山|岔林河漂流</h3>
							<p>铧子山由大铧子、二铧子、三铧子及其他山峰组成，因形似犁铧而得名，1987年曾在此地采到一棵重达505克的世界野山参“人参王”。岔林河发源于小兴安岭最高山——平顶山（白石砬子），岔林河环山而下，穿森林而过。两岸山峦叠嶂，景色迷人，夏季绿树成荫，百花盛开，秋季万山红遍，层林尽染，山里红、山丁子、臭李子等野果满枝，美不胜收。放筏岔林河、纵情山水间。</p>
							
						</div>
					</div>
				</div>
				<div class="divide20"></div>
			</div>
		</section>
		<!--/TEAM UNIT  -->
				
		<!-- SOCIAL BAR -->
		<section class="color-danger social text-center">
			<section class="container">
				<div class="row">
					<div class="col-md-12">
						<h3>Be up to date, follow us</h3>
							<!--<i class="fa fa-weibo-square fa-2x darkred rm20 bm10"></i>
							<i class="fa fa-facebook-square fa-2x darkred rm20 bm10"></i>
							<i class="fa fa-linkedin-square fa-2x darkred rm20 bm10"></i>			
							<i class="fa fa-youtube-square fa-2x darkred rm20 bm10"></i>
							<i class="fa fa-google-plus-square fa-2x darkred rm20 bm10"></i>-->
							<div style="margin:0 auto;width:200px;vertical-align: middle;">
							<div class="bdsharebuttonbox"><a href="#" class="bds_more" data-cmd="more"></a><a title="分享到QQ空间" href="#" class="bds_qzone" data-cmd="qzone"></a><a title="分享到新浪微博" href="#" class="bds_tsina" data-cmd="tsina"></a><a title="分享到人人网" href="#" class="bds_renren" data-cmd="renren"></a><a title="分享到微信" href="#" class="bds_weixin" data-cmd="weixin"></a></div>
<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"32"},"share":{}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>
					</div>
				</div>
			</section>
		</section>
		<!--/SOCIAL BAR -->
		
		<!-- CONTACT-US -->
		<section id="parallax-3" data-type="background" data-speed="10" class="pages text-center">
			<div class="parallax-overlay">
				<section id="contact">
					<section class="container">
						<div class="divide40"></div>
										<div class="row">
							<div class="col-md-12">
									<h2 class="text-center">
									<span class="bigintro-light">产品推荐联系我们</span>
									</h2>
							</div>
						</div>
						<div class="divide20"></div>
						<div class="row">
						<form action="<?php echo base_url()?>index.php/contact/addmessage" method="POST" enctype="multipart/form-data" />
							<div class="col-md-6 col-md-offset-3 form-input">
								<input id="company" type="text" placeholder="机构名称｜乌鸦泡绿色水稻基地|4-40字" name="company" value="<?php echo set_value('company')?>" />
								<?php echo form_error('company','<span>','</span>')?>
							</div>
							<div class="col-md-6 col-md-offset-3 form-input">
								<input id="title" type="text" placeholder="物产特色：野生菌类森林养殖|4-40" name="title" value="<?php echo set_value('title')?>" /><?php echo form_error('title','<span>','</span>')?>
							</div>
							<div class="col-md-6 col-md-offset-3 form-input">
								<input id="name" type="text" placeholder="联系人|2-10"name="name" value="<?php echo set_value('name')?>" /><?php echo form_error('name','<span>','</span>')?>
							</div>
							<div class="col-md-6 col-md-offset-3 form-input">
								<input id="tel" type="tel" placeholder="11位手机号" name="tel" value="<?php echo set_value('tel')?>" /><?php echo form_error('tel','<span>','</span>')?>
							</div>
							<div class="col-md-6 col-md-offset-3 form-input">
								<textarea id="message"  placeholder="棒打狍子瓢舀鱼野鸡飞到饭锅里，这里有亚洲最长的森林铁路|20-200" name="message"><?php echo set_value('message')?></textarea><?php echo form_error('message','<span>','</span>')?>
							</div>
							<div class="col-md-6 col-md-offset-3 form-submit">
								<button id="submit" class="btn btn-warning btn-lg" type="submit">提交</button>
							</div>
							</form>
						</div>
						<div class="divide60"></div>
					</section>
				</section>
			</div>
		</section>
		<!--/CONTACT-US -->
		
		<!-- FOOTER -->
		<section id="footer" class="color-light pattern">
			<div class="container">
				<div id="column-footer" class="row-fluid">
					<div class="col-sm-4">
						<h3>About Us</h3>
						<ul>
							<li><a href="#">关于我们</a></li>
							<li><a href="#">联系我们</a></li>
							<li><a href="#">©2017鸦哺之爱</a></li>
						</ul>
					</div>
					<div class="col-sm-4">
						<h3> HELP</h3>
						<ul>
							<li><a href="#">项目发起规范</a></li>
							<li><a href="#">服务协议</a></li>
							<li><a href="#">用户注册服务协议</a></li>
							<li><a href="#"> </a></li>
						</ul>
					</div>
					<div class="col-sm-4">
						<div>
						<img src="/style/base/img/qrcode.jpg" width="150" height="150">
						</div>
					</div>
				</div>
			  </div>
		</section>
		<!--/FOOTER -->
	</div>
	<!--/PAGE -->
	
	<!-- JAVASCRIPTS -->
	<!-- Placed at the end of the document so the pages load faster -->
	<script src="/style/base/js/jquery-1.9.1.min.js"></script>
	<script src="/style/base/bootstrap-dist/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="/style/base/js/waypoint/waypoints.min.js"></script>
	<script type="text/javascript" src="/style/base/js/navmaster/jquery.scrollTo.js"></script>
	<script type="text/javascript" src="/style/base/js/navmaster/jquery.nav.js"></script>
	<script src="/style/base/js/isotope/jquery.isotope.min.js" type="text/javascript"></script>
	<script type="text/javascript" src="/style/base/js/isotope/imagesloaded.pkgd.min.js"></script>
	<!-- COLORBOX -->
	<script type="text/javascript" src="/style/base/js/colorbox/jquery.colorbox.min.js"></script>
	<script src="/style/base/js/script.js"></script>
</body>
</html>