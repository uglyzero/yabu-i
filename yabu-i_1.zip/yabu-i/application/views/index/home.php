home
<hr />
<?php echo $title ?>
<hr />
<?php foreach($name as $v): ?>
	<span><?php echo $v ?></span>
<?php endforeach?>