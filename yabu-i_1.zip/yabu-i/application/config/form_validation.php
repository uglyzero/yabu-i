<?php
$config = array(
	'article'	=>	array(
			array(
				'field' => 'title',
				'label' => '标题',
				'rules' => 'required|min_length[5]'
			),
			array(
				'field' => 'cid',
				'label' => '分类',
				'rules' => 'integer'
			),
			array(
				'field' => 'flag_headline',
				'label' => '属性',
				'rules' => 'integer'
			),
			array(
				'field' => 'descript',
				'label' => '摘要',
				'rules' => 'required|max_length[100]'
			),
			array(
				'field' => 'content',
				'label' => '内容',
				'rules' => 'required|max_length[2000]'
			)
		),
	'contact' =>array(
			array(
				'field' => 'title',
				'label' => '标题',
				'rules' => 'required|min_length[4]|max_length[40]'
			),
			array(
				'field' => 'company',
				'label' => '机构｜个人',
				'rules' => 'required|min_length[4]|max_length[40]'
			),
			array(
				'field' => 'tel',
				'label' => '电话',
				'rules' => 'integer|min_length[11]|max_length[11]'
			),
			array(
				'field' => 'name',
				'label' => '联系人',
				'rules' => 'required|min_length[2]|max_length[10]'
			),
			array(
				'field' => 'message',
				'label' => '内容',
				'rules' => 'required|min_length[20]|max_length[2000]'
			)
		),
	'item' =>array(
			array(
				'field' => 'title',
				'label' => '标题',
				'rules' => 'required|min_length[4]|max_length[200]'
			),
			array(
				'field' => 'beg_time',
				'label' => '开始时间',
				'rules' => 'required|min_length[4]'
			),
			array(
				'field' => 'end_time',
				'label' => '结束时间',
				'rules' => 'required|min_length[4]'
			),
			array(
				'field' => 'goal_line',
				'label' => '目标额度',
				'rules' => 'integer|min_length[2]|max_length[10]'
			)
		),
	'item_pro' =>array(
			array(
				'field' => 'standard',
				'label' => '主题类型',
				'rules' => 'required|min_length[2]|max_length[20]'
			),
			array(
				'field' => 'invest_price',
				'label' => '目标额度',
				'rules' => 'integer|min_length[2]|max_length[10]'
			),
			array(
				'field' => 'repay',
				'label' => '回报说明',
				'rules' => 'required|min_length[2]|max_length[50]'
			)
		),

);
?>