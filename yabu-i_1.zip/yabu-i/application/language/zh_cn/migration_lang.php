<?php

$lang['migration_none_found']			= "没有发现迁移";
$lang['migration_not_found']			= "找不到这个迁移";
$lang['migration_multiple_version']		= "有多个迁移数据与此版本号相关: %d.";
$lang['migration_class_doesnt_exist']	= "这个迁移类 \"%s\" 无法找到。";
$lang['migration_missing_up_method']	= "这个迁移类 \"%s\" 缺少一个 'up' 方法。";
$lang['migration_missing_down_method']	= "这个迁移类 \"%s\" 缺少一个 'up' 方法。";
$lang['migration_invalid_filename']		= "迁移 \"%s\" 有 一个无效的文件名。";


/* End of file migration_lang.php */
/* Location: ./wc_content/language/zh_cn/migration_lang.php */
