<?

$lang['error_install_db_table_exited']="数据库表%s已存在，请将其删除以继续进行数据迁移。记得首先要备份您的重要数据。";

/* End of file profiler_lang.php */
/* Location: ./wc_content/language/zh_cn/error_lang.php */
