<?php

$lang['cal_su']			= "日";
$lang['cal_mo'] 		= "一";
$lang['cal_tu'] 		= "二";
$lang['cal_we'] 		= "三";
$lang['cal_th'] 		= "四";
$lang['cal_fr'] 		= "五";
$lang['cal_sa'] 		= "六";
$lang['cal_sun'] 		= "周日";
$lang['cal_mon'] 		= "周一";
$lang['cal_tue'] 		= "周二";
$lang['cal_wed'] 		= "周三";
$lang['cal_thu'] 		= "周四";
$lang['cal_fri'] 		= "周五";
$lang['cal_sat'] 		= "周六";
$lang['cal_sunday']		= "星期日";
$lang['cal_monday']		= "星期一";
$lang['cal_tuesday']	= "星期二";
$lang['cal_wednesday']	= "星期三";
$lang['cal_thursday']	= "星期四";
$lang['cal_friday']		= "星期五";
$lang['cal_saturday']	= "星期六";
$lang['cal_jan'] 		= "1";
$lang['cal_feb'] 		= "2";
$lang['cal_mar'] 		= "3";
$lang['cal_apr'] 		= "4";
$lang['cal_may'] 		= "5";
$lang['cal_jun'] 		= "6";
$lang['cal_jul'] 		= "7";
$lang['cal_aug'] 		= "8";
$lang['cal_sep'] 		= "9";
$lang['cal_oct'] 		= "10";
$lang['cal_nov'] 		= "11";
$lang['cal_dec'] 		= "12";
$lang['cal_january'] 	= "一月";
$lang['cal_february'] 	= "二月";
$lang['cal_march'] 		= "三月";
$lang['cal_april']		= "四月";
$lang['cal_mayl'] 		= "五月";
$lang['cal_june'] 		= "六月";
$lang['cal_july'] 		= "七月";
$lang['cal_august']		= "八月";
$lang['cal_september']	= "九月";
$lang['cal_october'] 	= "十月";
$lang['cal_november']	= "十一月";
$lang['cal_december'] 	= "十二月";


/* End of file calendar_lang.php */
/* Location: ./wc_content/language/zh_cn/calendar_lang.php */
