-- MySQL dump 10.13  Distrib 5.7.17, for Linux (x86_64)
--
-- Host: localhost    Database: cizc
-- ------------------------------------------------------
-- Server version	5.7.17-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(60) DEFAULT '',
  `descript` varchar(255) DEFAULT '' COMMENT '摘要',
  `cid` int(8) DEFAULT '0' COMMENT '栏目id',
  `content` text,
  `flag_headline` varchar(100) DEFAULT '0' COMMENT '属性',
  `keyword` varchar(100) DEFAULT '',
  `cre_time` int(2) DEFAULT '0',
  `edt_time` int(2) DEFAULT '0',
  `crt_user` varchar(20) DEFAULT '',
  `flag` int(11) DEFAULT '1' COMMENT '状态1可用0需审核-1不可用',
  `img` varchar(50) DEFAULT '' COMMENT '缩略图地址',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` VALUES (5,'为了寻找故乡舌尖上的味道，养殖吃松针，水果的走地鸡','养殖生态，食用安全的走地鸡，为让更多有朋友找到，曾经家乡的味道，为了一份浓浓的乡土情怀。',2,'<p><br></p><p><img src=\"/ueditor/php/upload/image/20170401/1491040557846541.jpg\" class=\"\"></p><p><img src=\"/ueditor/php/upload/image/20170401/1491040641127190.jpg\" class=\"\"></p><p><img src=\"/ueditor/php/upload/image/20170401/1491040642115356.jpg\" class=\"\"></p><p><img src=\"/ueditor/php/upload/image/20170401/1491040643488433.jpg\" class=\"\" width=\"750\" height=\"579\"></p><p><img src=\"/ueditor/php/upload/image/20170401/1491040644927862.jpg\" class=\"\" width=\"750\" height=\"467\"></p><p><img src=\"/ueditor/php/upload/image/20170401/1491040764225187.jpg\" class=\"\" width=\"750\" height=\"562\"></p><p><img src=\"/ueditor/php/upload/image/20170401/1491040765410151.jpg\" class=\"\" width=\"750\" height=\"609\"></p><p><br></p>','2','|livestock',0,1491040841,'0',1,'14899860444839.jpg'),(6,'东北黑土地 农家自产红小豆 非转基因红豆 天然五谷杂粮','纯正农家自产非转基因红豆，无农药化肥，健康无污染。适合做红豆汤.红豆薏米粥.豆沙包等等，易煮烂，易出沙。500*2/15元',2,'<p><img src=\"/ueditor/php/upload/image/20170401/1491044240474058.gif\" class=\"\"><img src=\"/ueditor/php/upload/image/20170401/1491044240594624.gif\" class=\"\"><img src=\"/ueditor/php/upload/image/20170401/1491044241855578.gif\" class=\"\"><img src=\"/ueditor/php/upload/image/20170401/1491044242449684.gif\" class=\"\"><img src=\"/ueditor/php/upload/image/20170401/1491044242921645.gif\" class=\"\"><img src=\"/ueditor/php/upload/image/20170401/1491044445494847.gif\" class=\"\"></p><p><img src=\"/ueditor/php/upload/image/20170401/1491044497515877.jpg\"></p><p> </p><p><img src=\"/ueditor/php/upload/image/20170401/1491044552443362.jpg\"></p><p> </p><p><img src=\"/ueditor/php/upload/image/20170401/1491044552359005.jpg\"></p><p><br></p>','2','|farming',0,1491142787,'0',1,'14911427875454.jpg'),(7,'2自己的田，自己的米，自己种，才放心！','1在食品安全问题日益严重的今天，我们相信只有真正自己的地种出来的大米才能够令人安心。精选黄金良田、优质稻种',2,'<p>2在食品安全问题日益严重的今天，我们相信只有真正自己的地种出来的大米才能够令人安心。精选黄金良田、优质稻种</p>','2','|farming',0,1489989995,'0',-1,'14899643714781.jpg'),(9,'东兴吊应野生金花茶——“植物界大熊猫”“茶族皇后”','通过电商众筹让吊应村的金花茶有一个直销全国各地的通路，减少中间交易环节，打破高价炒作，让村民们获得应有的收',2,'<p>通过电商众筹让吊应村的金花茶有一个直销全国各地的通路，减少中间交易环节，打破高价炒作，让村民们获得应有的收</p>','2','|farming',0,1489985944,'0',-1,'14899712619765.jpg'),(10,'明前茶，贵如金，高山氧吧出好茶，黄山毛峰等您品','我小邵来自安徽省黄山市歙县长标村，相信很多喝过绿茶的人都知道黄山毛峰，而当今最好喝的绿茶毛峰我认为是',2,'<p>我小邵来自安徽省黄山市歙县长标村，相信很多喝过绿茶的人都知道黄山毛峰，而当今最好喝的绿茶毛峰我认为是</p>','2','|farming|forestry',1489980292,1489985935,'0',-1,'14899714333464.jpg'),(11,'优质东北大米 黑龙江大米 通河县大米 稻花香 ','东北大米不止有五常稻花香，来自“稻谷之乡”和“水稻王国”通河县大米 稻花香 品质保障，拒绝“李鬼五常米”，安心选择通河米。3kg／30元',2,'<p><img src=\"/ueditor/php/upload/image/20170401/1491040086538721.jpg\" class=\"\"><img src=\"/ueditor/php/upload/image/20170401/1491040086638485.jpg\" class=\"\"></p><p><img src=\"/ueditor/php/upload/image/20170401/1491040276389329.jpg\" class=\"\"><img src=\"/ueditor/php/upload/image/20170401/1491040277774384.jpg\" class=\"\"><img src=\"/ueditor/php/upload/image/20170401/1491040278320177.jpg\" class=\"\"><img src=\"/ueditor/php/upload/image/20170401/1491040279354057.jpg\" class=\"\"></p>','2','|farming',1489988217,1491040280,'',1,'14902028321983.jpg'),(12,'东北黑蜂椴树蜜 蜂巢蜜 结晶雪蜜 白蜜 天然农家自产','东北黑蜂椴树蜜 蜂巢蜜 结晶雪蜜 白蜜 天然农家自产 500g/58元',2,'<p><img src=\"/ueditor/php/upload/image/20170401/1491038846537073.jpg\" class=\"\"><img src=\"/ueditor/php/upload/image/20170401/1491038847307877.jpg\" class=\"\"><img src=\"/ueditor/php/upload/image/20170401/1491038847127540.jpg\" class=\"\"><img src=\"/ueditor/php/upload/image/20170401/1491038848557470.jpg\" class=\"\"></p><p><img src=\"/ueditor/php/upload/image/20170401/1491038873802544.jpg\" class=\"\"></p>','2','|forestry',1489988454,1491039319,'',1,'14901985417776.jpg'),(13,'原味山核桃仁 东北特产生大核桃仁','原味山核桃仁 可以生吃，熬粥，打豆浆，打米糊，月饼，糕点，炒熟更香哦～孕妇首选 260g／35元',2,'<p><img class=\"img-ks-lazyload\" alt=\"\" src=\"/ueditor/php/upload/image/20170401/1491039635857851.jpg\"></p><p><img class=\"img-ks-lazyload\" alt=\"\" src=\"/ueditor/php/upload/image/20170401/1491039636723179.jpg\"></p><p><img class=\"img-ks-lazyload\" alt=\"\" src=\"/ueditor/php/upload/image/20170401/1491039636195782.jpg\"></p><p><img class=\"img-ks-lazyload\" alt=\"\" src=\"http://www.yabu-i.com/ueditor/php/upload/image/20170401/1491039641645023.jpg\"></p><p><img class=\"img-ks-lazyload\" alt=\"\" src=\"/ueditor/php/upload/image/20170401/1491039637903555.jpg\"></p><p></p><p><img class=\"img-ks-lazyload\" alt=\"\" src=\"/ueditor/php/upload/image/20170401/1491039640705031.jpg\"></p><p><img class=\"img-ks-lazyload\" alt=\"\" src=\"/ueditor/php/upload/image/20170401/1491039643127480.jpg\"></p><p><img class=\"img-ks-lazyload\" alt=\"\" src=\"/ueditor/php/upload/image/20170401/1491039644561782.jpg\"></p><p><img class=\"img-ks-lazyload\" alt=\"\" src=\"/ueditor/php/upload/image/20170401/1491039645366039.jpg\"></p><p><br></p>','2','|forestry',1489988901,1491039715,'',1,'14901976125455.jpg'),(14,'正宗土猪肉东北笨猪肉 农家散养猪 山林放养365天以上，膘厚、肉香，真正东北农村土猪！','正宗东北土猪黑毛猪 笨猪肉 农家散养猪 山林放养365天以上，膘肥适中，肉质香。 肋排1000g／78元',2,'<p><img class=\"img-ks-lazyload\" src=\"/ueditor/php/upload/image/20170401/1491041290257585.jpg\" width=\"700\" height=\"680\"><br></p><p><img class=\"img-ks-lazyload\" src=\"/ueditor/php/upload/image/20170323/1490200047682527.jpg\" title=\"1490200047682527.jpg\" alt=\"TB2h3ubbSKI.eBjy1zcXXXIOpXa_!!2433348449.jpg\" width=\"700\"></p>','2','|livestock',1489989179,1491041571,'',1,'14902000587735.jpg'),(15,'有机椴木无根秋木耳 东北特产干货小碗耳','有机椴木无根秋木耳 东北特产干货小碗耳 人工挑选 肉质肥厚 泡发比高 味道鲜美 260g/30元',2,'<p><br></p><p><br></p><p><strong xss=removed><img src=\"/ueditor/php/upload/image/20170401/1491038087132288.jpg\"></strong></p><p><strong xss=removed><img src=\"/ueditor/php/upload/image/20170401/1491038167459987.jpg\" class=\"\"><img src=\"/ueditor/php/upload/image/20170401/1491038167245253.jpg\" class=\"\"><img src=\"/ueditor/php/upload/image/20170401/1491038168935755.jpg\" class=\"\"></strong></p>','2','|forestry',1489989357,1491038174,'',1,'14901965928783.jpg'),(16,'野生榛蘑干货榛蘑丁东北特产榛蘑250克无根','小兴安岭野生榛蘑干货，全部手工一朵朵精心挑选、剪根，即省事又无损耗，小蘑菇芽，口感更嫩~~250g*2/60元',2,'<p><img src=\"/ueditor/php/upload/image/20170401/1491037128344052.jpg\" class=\"\"><img src=\"/ueditor/php/upload/image/20170401/1491037129554516.jpg\" class=\"\"><img src=\"/ueditor/php/upload/image/20170401/1491037129595438.jpg\" class=\"\"><img src=\"/ueditor/php/upload/image/20170401/1491037130768941.jpg\" class=\"\"></p>','2','|forestry',1489989649,1491037158,'',1,'14901943688215.jpg'),(17,'黑龙江非转基因大豆 东北黄豆手工精选 豆王豆 磨豆浆首选','黑龙江非转基因大豆 机器筛选之后人工手选的超大颗粒黄豆豆王豆 磨豆浆首选 600g*2/15元',2,'<p><a target=\"_blank\"><img src=\"/ueditor/php/upload/image/20170401/1491036158169987.jpg\" class=\"\"><br></a></p><p><img src=\"/ueditor/php/upload/image/20170401/1491036303909462.jpg\"><a target=\"_blank\"></a></p>','2','|farming',1489989901,1491036314,'',1,'14901910993336.jpg'),(18,'东北松子开口 大颗粒 笨炒非油炸松子手剥野生原味','东北松子开口 大颗粒 笨炒非油炸松子手剥野生原味 不去看别人卖什么价格，只对黑土地的品质负起责任；原味、笨炒、非油炸，营养又健康 225g*2/50元',2,'<p>    <span xss=removed><span xss=removed><span xss=removed>红松子也称海松子，只有<span xss=removed>中国</span>东北有。红松子是“三年一小收，五年一大收”，所以并不是所有年头都是丰收年。</span></span></span></p><p><img src=\"/ueditor/php/upload/image/20170401/1491035515424752.gif\" class=\"\"></p><p><span xss=removed><span xss=removed>      松子的采摘只有一个方式，人工。在几十米高的红松上打松塔是一项极其危险的工作，稍有不慎就有掉下来的危险，每年都有林农出意外的，所以红松子来之不易，稀有珍贵是有道理的！</span></span></p><p><span xss=removed><span xss=removed><span xss=removed> </span></span></span></p><p><span xss=removed>    这是林区老百姓冒着危险打下来的松塔，当我们吃到美味的松子的时候，我们不曾</span><span xss=removed>想到它们得来其实并不容易。</span></p><p><span xss=removed><span xss=removed><span xss=removed><span xss=removed><img src=\"/ueditor/php/upload/image/20170401/1491035516433644.jpg\" class=\"\"></span></span></span></span></p><p><span xss=removed><span xss=removed>     松塔表面沾满透明的松油，要经过堆放和晒制才可以脱粒。鲜松塔是绿色的，自然晒干后的松塔是黄色的，自然晒干的松子特别香。</span></span></p><p><span xss=removed><span xss=removed><img src=\"/ueditor/php/upload/image/20170401/1491035517288997.jpg\" class=\"\"><img src=\"/ueditor/php/upload/image/20170401/1491035518517305.gif\" class=\"\"></span></span></p><p> </p><p><img src=\"/ueditor/php/upload/image/20170401/1491035518849695.jpg\" class=\"\"></p><p><img src=\"/ueditor/php/upload/image/20170401/1491035519663472.jpg\" class=\"\"><img src=\"/ueditor/php/upload/image/20170401/1491035520530152.jpg\" class=\"\"></p>','2','|forestry',1490192808,1491035639,'',1,'14901928088885.jpg'),(19,'东北特产北五味子野生特级油籽','小兴安岭野生五味子，自然晾晒，绿色，天然，不添加任何防腐剂，无熏硫，真正的野生五味子籽，药效好，成分足。220g/50元',2,'<p><img src=\"https://img.alicdn.com/imgextra/i3/1661046481/TB2zipPrVXXXXb.XXXXXXXXXXXX_!!1661046481.jpg\"><img src=\"https://img.alicdn.com/imgextra/i3/1661046481/TB2vU8ArVXXXXXnXpXXXXXXXXXX_!!1661046481.jpg\" class=\"\"><img src=\"https://img.alicdn.com/imgextra/i4/1661046481/TB2KL82rVXXXXXWXXXXXXXXXXXX_!!1661046481.jpg\" class=\"\"><img src=\"https://img.alicdn.com/imgextra/i3/1661046481/TB2e6FjrVXXXXciXpXXXXXXXXXX_!!1661046481.jpg\" class=\"\"><img src=\"https://img.alicdn.com/imgextra/i1/1661046481/TB2aZlwrVXXXXXNXpXXXXXXXXXX_!!1661046481.jpg\" class=\"\"><img src=\"https://img.alicdn.com/imgextra/i1/1661046481/TB2vUVDrVXXXXc8XXXXXXXXXXXX_!!1661046481.jpg\" class=\"\"><img src=\"https://img.alicdn.com/imgextra/i4/1661046481/TB2LRdNrVXXXXcuXXXXXXXXXXXX_!!1661046481.jpg\" class=\"\"><img src=\"https://img.alicdn.com/imgextra/i1/1661046481/TB2vQRIrVXXXXcSXXXXXXXXXXXX_!!1661046481.jpg\" class=\"\"><img src=\"https://img.alicdn.com/imgextra/i4/1661046481/TB2w_RorVXXXXbUXpXXXXXXXXXX_!!1661046481.jpg\" class=\"\"><img src=\"https://img.alicdn.com/imgextra/i2/1661046481/TB2GsNBrVXXXXc5XXXXXXXXXXXX_!!1661046481.jpg\" class=\"\"></p>','2','|forestry',1491045430,1491294539,'',1,'14911427386101.jpg'),(20,'通往小兴安岭的森林小火车——陪驴走天下','http://blog.sina.com.cn/s/blog_65f0c74b0100tcrz.html',4,'<p>今年春节，在家听北京的孟同学说，到兴隆镇你能看见窄轨小火车，看了他发在论坛上的照片，于是内心汹涌澎湃，梦想着一定要去东北感受感受这开往小兴安岭的森林小火车，于是乎四月份从广州一路向北，到达这可以坐小火车的地方，只可惜来的时候，是双日，小火车停运，现在林业局的规定，单日早上六点半开一班，其他时间停运。说起这小火车，历史不算太久，但是名气却很大，因为这是全世界最长的一条森铁。</p>','2','|farming',1491194910,1491197323,'',1,'14911962028284.jpg'),(21,'森林小火车之旅(二)香磨山 慈航古寺—— 抱拙斋人','http://blog.sina.com.cn/s/blog_5d92963d0100e9yy.html',4,'<p>在山上住了一夜,第二天一早,我们又乘坐小火车开始了新的旅程\r\n\r\n---两个小时左右我们来到了香磨山,拜访了黑龙江省第一大寺庙---\r\n\r\n慈航古寺</p>','0','|farming',1491196969,1491197368,'',1,'14911969691123.jpg'),(22,'森林小火车之旅—— 抱拙斋人','http://blog.sina.com.cn/s/blog_5d92963d0100e9yw.html',4,'<p>6月13日,我们怀着好奇,前往兴隆林场,开始了森林小火车之旅.我们坐在颠簸摇摆的小火车上. 两个多小时后,我们到达第一站--高丽寨.在这里居住的全部是朝鲜族人</p>','0','|farming',1491197190,1491197207,'',1,'14911971905112.jpg'),(23,'兴隆林区小火车的故事—— 史义军的博客','http://blog.sina.com.cn/s/blog_616c456c0102whp0.html',4,'<p>兴隆林业局小火车可以说闻名遐迩，在世界铁路史上也可以写上一笔的，据说现在还有180公里的铁路线。可是因为道路年久失修，小火车已经无法像二十多年前那样——咣里咣当拉着汽笛冒着浓烟在林区穿梭了。</p>','2','|farming',1491197724,1491197739,'',1,'14911977242092.jpg'),(24,'2016登山之旅 铧子山——*呈诺* ','http://www.mafengwo.cn/i/6137750.html',4,'<p>每一个暑期我们都会带宝贝去爬山，既锻炼意志又能欣赏祖国的大好河山，何乐而不为呢？呵呵。今年暑期的高温天气，也促使我们找一避暑之地。自驾，有太多因素需要考虑，又不想太远，经过再三选择就选了黑龙江通河县的铧子山。</p>','2','|farming',1491198069,1491198086,'',1,'14911980697476.jpeg'),(25,'2013年国庆通河铧子山一日游记——鲲鹏展翅','http://www.mafengwo.cn/i/2943094.html',4,'<p>在我们美丽的家乡——哈尔滨大约160公里开外有一座县城名叫通河县，离县城不到30公里有座名山叫铧子山，这是一座英雄的山，当年东北抗日联军在此与侵华日军进行血战，久仰其名。早就有到此一游，领略当年抗战余韵，缅怀抗联英烈之意。恰逢国庆黄金周，与我的同事商议，立即动身前往，故书此游记，和大家共享，不到之处敬请谅解！</p>','0','|farming',1491198532,0,'',1,'14911985324536.jpeg'),(26,'走近黑龙江木兰兴隆鸡冠山——郭柏林','http://blog.sina.com.cn/s/blog_934bc8eb0101maqg.html',4,'<p>去年年初我接受兴隆林业局局长王礼堂的邀请为正在开发建设中的鸡冠山景区拍画册，只因为礼堂局长是原山河屯林业局局长，十几年前他开发建设凤凰山景区时第一本画册由我来拍摄的。原打算去年四季下来拍摄任务能基本完成，因为去年秋季和冬季气象原因秋季色彩不艳冬季无雾凇所以今年继续拍摄。</p>','2','|farming',1491199298,1491199341,'',1,'14911992982531.jpg'),(27,'兴隆林业局鸡冠山密营遗址群考察记——史义军','http://blog.sina.com.cn/s/blog_616c456c0102w6bk.html',4,'<p>这个密营遗址坐落在鸡冠山景区小鸡冠山后背，当地土名叫簸箕掌，也是一个坐北朝南的椅子型的密营。这个密营共有十八个地窨子，在山脊上分布有十三处散兵坑。</p>','2','|farming',1491199459,1491201577,'',1,'14911994592759.jpg');
/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `company` varchar(100) DEFAULT '',
  `title` varchar(100) DEFAULT '',
  `name` varchar(40) DEFAULT '',
  `tel` varchar(20) DEFAULT '',
  `message` text,
  `cretime` int(11) DEFAULT '0',
  `IP` varchar(20) DEFAULT '',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` VALUES (6,'青锋山庄','野生榛蘑','顺德','13800000001','棒打狍子瓢舀鱼野鸡飞到饭锅里，这里有亚洲最长的森林铁路',1490075475,'127.0.0.2'),(7,'五常大米通河种植基地','五常大米通河种植基地','孙守一','13800000001','五常大米通河种植基地五常大米通河种植基地',1490077461,'127.0.0.1'),(8,'探讨探讨探讨探讨探讨探讨','ffffffff','ffffff','13800000001','京ICP备1350145\r\n京公网安备11010500216062\r\n食品流通许可证',1490147521,'127.0.0.1'),(9,'青峰山庄','ffffffff','顺得','13800000001','form_validation.phpform_validation.phpform_validatioform_validation.phpn.php',1490147555,'127.0.0.1'),(10,'青峰山庄','野生榛蘑','顺得','13800000001','form_validation.phpform_validation.phpform_validation.phpform_validation.php',1490147752,'127.0.0.1');
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `art_id` int(11) DEFAULT '0' COMMENT 'articleid',
  `title` varchar(255) DEFAULT '',
  `beg_time` int(11) DEFAULT '0' COMMENT '开始时间',
  `end_time` int(11) DEFAULT '0' COMMENT '结束时间',
  `goal_line` int(11) DEFAULT '0' COMMENT '目标额度',
  `finish_line` int(11) DEFAULT '0' COMMENT '完成额度',
  `flag` int(2) DEFAULT '0' COMMENT '0初始6开始9结束',
  `content` varchar(255) DEFAULT '' COMMENT '说明-项目特殊介绍联系信息等',
  `c_userid` varchar(20) DEFAULT '' COMMENT '添加人id',
  `chk_note` varchar(50) DEFAULT '' COMMENT '审核备注',
  `c_time` int(11) DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item`
--

LOCK TABLES `item` WRITE;
/*!40000 ALTER TABLE `item` DISABLE KEYS */;
INSERT INTO `item` VALUES (3,19,'东北特产北五味子野生特级油籽',1488297600,1490803200,3500,2680,6,'','zero','',1491189938),(5,18,'东北松子开口 大颗粒 笨炒非油炸松子手剥野生原味',1483200000,1485792000,2800,5280,6,'','zero','',1491190102),(6,17,'黑龙江非转基因大豆 东北黄豆手工精选 豆王豆 磨豆浆首选',1473868800,1476460800,4500,3255,6,'','zero','',1491205023),(7,16,'野生榛蘑干货榛蘑丁东北特产榛蘑250克无根',1474300800,1476892800,3300,2988,6,'','zero','',1491205227),(8,15,'有机椴木无根秋木耳 东北特产干货小碗耳',1478016000,1480435200,4000,7865,6,'','zero','',1491205408),(9,14,'正宗土猪肉东北笨猪肉 农家散养猪 山林放养365天以上，膘厚、肉香，真正东北农村土猪！',1482595200,1485273600,5000,6872,6,'','zero','',1491191587),(10,11,'优质东北大米 黑龙江大米 通河县大米 稻花香 ',1477324800,1482595200,9000,11868,6,'','zero','',1491205612),(11,13,'原味山核桃仁 东北特产生大核桃仁',1474732800,1483027200,10000,6950,6,'','zero','',1491205790),(12,12,'东北黑蜂椴树蜜 蜂巢蜜 结晶雪蜜 白蜜 天然农家自产',1472659200,1477929600,6000,11850,6,'','zero','',1491205975),(13,5,'为了寻找故乡舌尖上的味道，养殖吃松针，水果的走地鸡',1483200000,1485878400,5000,3685,6,'','zero','',1491206208),(14,6,'东北黑土地 农家自产红小豆 非转基因红豆 天然五谷杂粮',1475251200,1477929600,2800,5328,9,'','zero','',1491291931);
/*!40000 ALTER TABLE `item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_pro`
--

DROP TABLE IF EXISTS `item_pro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_pro` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `art_id` int(11) DEFAULT '0' COMMENT 'articleid',
  `item_id` int(11) DEFAULT '0' COMMENT '项目id',
  `standard` varchar(50) DEFAULT '' COMMENT '规格 型号',
  `invest_price` int(11) DEFAULT '0' COMMENT '投资金额',
  `repay` varchar(255) DEFAULT '' COMMENT '回报说明',
  `pro_price` int(11) DEFAULT '0' COMMENT '添加则项目结束后成为商品可购买',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COMMENT='项目产品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_pro`
--

LOCK TABLES `item_pro` WRITE;
/*!40000 ALTER TABLE `item_pro` DISABLE KEYS */;
INSERT INTO `item_pro` VALUES (1,19,3,'220g',40,'220g',50),(2,19,3,'500g',85,'500g',95),(3,19,3,'1000g',160,'1000g',180),(4,18,5,'225g',25,'225g',30),(5,18,5,'500g',45,'500g',55),(6,18,5,'1000g',85,'1000g',90),(7,18,5,'2000g',160,'2000g',170),(8,14,9,'肋排|五花1000g',78,'肋排1000g',85),(9,14,9,'后臀1000g',68,'后臀1000g',80),(10,14,9,'肋排|五花2000g',155,'肋排|五花2000g',180),(11,14,9,'后臀2000g',135,'后臀2000g',150),(12,6,14,'1000g',12,'1000g',15),(13,6,14,'5kg',59,'5kg',65),(14,17,6,'1000g',12,'1000g',15),(15,17,6,'5kg',55,'5kg',65),(16,16,7,'250g',25,'250g',32),(17,16,7,'500g',48,'200g',60),(18,16,7,'1000g',90,'1000g',110),(19,15,8,'250g',28,'250g',35),(20,15,8,'500g',55,'500g',70),(21,15,8,'1000g',100,'1000g',120),(22,11,10,'1kg',10,'1kg',15),(23,11,10,'5kg',48,'5kg',70),(24,11,10,'10kg',90,'10kg',135),(25,13,11,'500g',65,'500g',70),(26,13,11,'1000g',120,'1000g',135),(27,12,12,'500g',55,'500g',60),(28,12,12,'2kg',200,'2kg',220),(29,12,12,'5kg',490,'5kg',550),(30,5,13,'1000g',78,'1000g',88);
/*!40000 ALTER TABLE `item_pro` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-04-27 21:56:01
